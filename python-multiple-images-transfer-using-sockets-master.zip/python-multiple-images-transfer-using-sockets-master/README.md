# python-multiple-images-transfer-using-sockets
Send multiple images from Client to Server using socket and zipfile modules
### Usage:
#### Server
```
python server.py
```

#### Client
```
python client.py 3
```
Here, argument denotes the number of images to send
